library("testthat")

library("recommenderlab")
test_check("recommenderlab")
